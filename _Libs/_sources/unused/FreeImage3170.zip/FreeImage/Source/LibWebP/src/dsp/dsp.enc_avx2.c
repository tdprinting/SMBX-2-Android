// Copyright 2014 Google Inc. All Rights Reserved.
//
// Use of this source code is governed by a BSD-style license
// that can be found in the COPYING file in the root of the source
// tree. An additional intellectual property rights grant can be found
// in the file PATENTS. All contributing project authors may
// be found in the AUTHORS file in the root of the source tree.
// -----------------------------------------------------------------------------
//
// AVX2 version of speed-critical encoding functions.

#include "./dsp.h"

#if defined(WEBP_USE_AVX2)

#endif  // WEBP_USE_AVX2

//------------------------------------------------------------------------------
// Entry point

extern void VP8EncDspInitAVX2(void);

void VP8EncDspInitAVX2(void) {
}
